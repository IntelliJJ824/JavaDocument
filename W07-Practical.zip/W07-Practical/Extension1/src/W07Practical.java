import java.sql.SQLException;

/**
 * This is for executing W07Practical.
 */
public class W07Practical {
    public static void main(String[] args) throws SQLException{
        // If the program args are less or more
        if(args.length < 2 || args.length > 3) {
            System.out.println("Usage: java -cp sqlite-jdbc.jar:. W07Practical <db_file> <action> [input_file]");
        } else {
            // This is for creating a file
            if(args.length == 3) {
                jdbcControl control = new jdbcControl(args[0], args[1], args[2]);
            } else {
                jdbcControl control = new jdbcControl(args[0], args[1]);
            }
        }
    }
}
