import java.sql.SQLException;
public class jdbcControl {
    private String action;
    private actionMethod finder;

    /**
     *
     * @param dbFile the file name is to be read.
     * @param action the query String that user enter.
     * @param fileLocation the file need to be read.
     * @throws SQLException cannot connect to database
     */
    public jdbcControl(String dbFile, String action, String fileLocation) throws SQLException{
        this.action = action;
        finder = new actionMethod(dbFile, fileLocation);
        actionSelect();
    }

    public jdbcControl(String dbFile, String action) throws SQLException{
        this.action = action;
        finder = new actionMethod(dbFile, "not necessary");
        actionSelect();
    }

    /**
     * This method is to control the selection for users
     * @throws SQLException cannot connect to sql.
     */
    public void actionSelect() throws SQLException{
        switch (action) {
            case "create":
                System.out.println("OK");
                finder.createTable();
                break;
            case "query1":
                System.out.println("passengerId, survived, pClass, name, sex, age, sibSp, parch, ticket, fare, cabin, embarked");
                finder.accessDB();
                finder.printTable();
                break;

            case "query2":
                System.out.println("Number of Survivors");
                finder.accessDB();
                finder.findSurvivors();
                break;

            case "query3":
                System.out.println("pClass, survived, count");
                finder.accessDB();
                finder.findPclass();
                break;

            case "query4":
                System.out.println("sex, survived, minimum age");
                finder.accessDB();
                finder.findMinAge();
                break;

            case "query5":
                System.out.println("pClass, Maximum fees, Minimum fees (except 0)");
                finder.accessDB();
                finder.findMaximumFare();
                break;

            default:
                System.out.println("Query No Found");
        }
    }
}
