import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

public class actionMethod {
    private String fileLocation, dbUrl;
    Connection connection = null;
    private final int PASSENGER_ID = 0;
    private final int SURVIVED = 1;
    private final int PCLASS = 2;
    private final int NAME = 3;
    private final int SEX = 4;
    private final int AGE = 5;
    private final int SIBSP = 6;
    private final int PARCH = 7;
    private final int TICKET = 8;
    private final int FARE = 9;
    private final int CABIN = 10;
    private final int EMBARKED = 11;


    public actionMethod(String dbFile, String fileLocation) {
        this.fileLocation = fileLocation;
        dbUrl= "jdbc:sqlite:" + dbFile;
    }

    public void accessDB() throws SQLException{
        try {
            connection = DriverManager.getConnection(dbUrl);
        } catch(SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     *
     * @throws SQLException when the SQL is not exist or cannot link to the database.
     * This method will be used when the user enter 'create' option.
     * This method is associated with addDetail method.
     */

    public void createTable() throws SQLException {
        connection = DriverManager.getConnection(dbUrl);

        Statement statement = connection.createStatement();
        //create the table called persons.
        statement.executeUpdate("DROP TABLE IF EXISTS Persons");
        statement.executeUpdate(
                "CREATE TABLE Persons(" +
                        "peopleNo INTEGER PRIMARY KEY AUTOINCREMENT,"+
                        "passengerId INTEGER," +
                        "survived INTEGER, " +
                        "name VARCHAR(50),"+
                        "sex VARCHAR(10)," +
                        "age FLOAT, " +
                        "sibSp INTEGER)"
        );

        //create the other table called boats.
        statement.executeUpdate("DROP TABLE IF EXISTS Tickets");
        statement.executeUpdate(
                "CREATE TABLE Tickets(" +
                        "ticketsNo INTEGER PRIMARY KEY AUTOINCREMENT,"+
                        "ticket VARCHAR(20)," +
                        "pClass INTEGER, " +
                        "parch INTEGER, " +
                        "fare FLOAT, " +
                        "embarked VARCHAR(2)," +//cabin VARCHAR (6)
                        "cabin VARCHAR (6))");
        addDetails();
        statement.close();
        connection.close();
    }

    /**
     * This method is to add some details into the table, which is called by the method createTable().
     * @throws SQLException
     */
    public void addDetails() throws SQLException{
        Statement statement = connection.createStatement();
        // The following codes is to read the details in CSV file.
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(fileLocation));
            reader.readLine();
            String line;
            while((line = reader.readLine()) != null) {
                String[] words = line.split(",");

                //insert the details into the table.
                for (int i = 0; i < words.length; i++) {
                    if(words[i].isEmpty()) {
                        words[i] = null;
                    }

                }

                // for empty large file
                ArrayList<String> wordsList = new ArrayList<>();
                for (int i = 0; i < words.length; i++) {
                    wordsList.add(words[i]);
                }
                if (wordsList.size() < 12) {
                    wordsList.add(null);
                }

                //This is the control to insert info to Persons
                String updateString = "INSERT INTO Persons(passengerId, survived, name, sex, age, sibSp) VALUES(" +
                            " " + wordsList.get(PASSENGER_ID) + "," +
                            " " + wordsList.get(SURVIVED) +", " +
                            " "+ wordsList.get(NAME) + "," +
                            " '" + wordsList.get(SEX) + "'," +
                            " "+ wordsList.get(AGE) +", "+
                            " " + wordsList.get(SIBSP) + ")";
                statement.executeUpdate(updateString);

                //This is the control to insert info to tickets
                updateString = "INSERT INTO Tickets(ticket, pClass, parch, fare, embarked, cabin) VALUES(" +
                        " '" + wordsList.get(TICKET) + "', " +
                        " " + wordsList.get(PCLASS) + ", " +
                        " " + wordsList.get(PARCH) + ", " +
                        " " + wordsList.get(FARE) + ", " +
                        " '" + wordsList.get(EMBARKED) + "', "+
                        " '" + wordsList.get(CABIN) + "')";
                statement.executeUpdate(updateString);
            }
        } catch (IOException e) {
            e.getMessage();
        } finally {
                if(reader != null) {
                   try {
                       reader.close();
                   } catch(IOException error) {
                       error.getMessage();
                   }
                }
        }
        statement.close();
    }


    /**
     * this method is to print out the data in the database.
     * @throws SQLException when the SQL is not exist or cannot link to the database.
     */

    public void printTable() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSetPersons = statement.executeQuery("SELECT Persons.passengerId, Persons.survived, Tickets.pClass, Persons.name, Persons.sex, Persons.age,Persons.sibSp," +
                "Tickets.parch, Tickets.ticket, Tickets.fare, Tickets.cabin, Tickets.embarked FROM Persons, Tickets WHERE Persons.peopleNo = Tickets.ticketsNo");
        ResultSetMetaData rsmd = resultSetPersons.getMetaData();
        int size = rsmd.getColumnCount();
        while (resultSetPersons.next()) {
            for (int i = 1; i <= size; i++) {
                if (i == size) { // the last details without information.
                    System.out.print(resultSetPersons.getString(i));
                }
                else if (i== 4) { //if this is a name
                    System.out.print("\"" + resultSetPersons.getString(i) + "\", ");
                }
                else {
                    System.out.print(resultSetPersons.getString(i) + ", ");
                }
            }
            System.out.println();
        }
        statement.close();
        connection.close();
    }

    /**
     * This program is to count how many survivors in the boat, which is for query 2.
     * @throws SQLException when the SQL is not exist or cannot link to the database.
     */
    public void findSurvivors() throws SQLException{
        Statement statement = connection.createStatement();
        ResultSet resultSurvivors = statement.executeQuery("SELECT Persons.survived FROM Persons");

        int countSurvivors = 0;
        while (resultSurvivors.next()) {
            String peopleSituation = resultSurvivors.getString(SURVIVED);
            //get the people who are survivors
            if (survivorsJudgement(peopleSituation)) {
                countSurvivors ++;
            }
        }
        System.out.println(countSurvivors);
        statement.close();
        connection.close();
    }

    public void findMaximumFare() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultFare = statement.executeQuery("SELECT Tickets.pClass, Tickets.fare FROM Tickets");
        //This is the fare for Maximum
        double firstClassMaxFee = 0;
        double secondClassMaxFee = 0;
        double thirdClassMaxFee = 0;
        //This is the fare for Minimum
        double firstClassMinFee = 1000;
        double secondClassMinFee = 1000;
        double thirdClassMinFee = 1000;

        while (resultFare.next()) {
            String pClass = resultFare.getString(1);
            String fare = resultFare.getString(2);
            double fareClass = Double.parseDouble(fare);

            switch (pClass) {
                case "1":
                    if (fareMaxCompare(firstClassMaxFee, fareClass)) {
                        firstClassMaxFee = fareClass;
                    }
                    else if (findMinimum(firstClassMinFee, fareClass) && fareClass > 0) {
                        firstClassMinFee = fareClass;
                    }
                    break;
                case "2":
                    if (fareMaxCompare(secondClassMaxFee, fareClass)) {
                        secondClassMaxFee = fareClass;
                    }
                    else if (findMinimum(secondClassMinFee, fareClass ) && fareClass > 0) {
                        secondClassMinFee = fareClass;
                    }
                    break;
                case "3":
                    if (fareMaxCompare(thirdClassMaxFee, fareClass)) {
                        thirdClassMaxFee = fareClass;
                    }
                    else if (findMinimum(thirdClassMinFee, fareClass) && fareClass > 0) {
                        thirdClassMinFee = fareClass;
                    }
                    break;
                default:
                    System.out.println("There is no such a class");
            }
        }

        System.out.println(1 + ", " + firstClassMaxFee + ", " + firstClassMinFee);
        System.out.println(2 + ", " + secondClassMaxFee + ", " + secondClassMinFee);
        System.out.println(3 + ", " + thirdClassMaxFee +", "+ thirdClassMinFee);
        statement.close();
        connection.close();
    }

    public boolean fareMaxCompare(double maxFare, double curFare ) {
        return maxFare < curFare;
    }

    /**
     * This method is for query3, which call the method to judge whether people survive.
     * @throws SQLException when the SQL is not exist or cannot link to the database.
     */

    public void findPclass() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultPclass = statement.executeQuery("SELECT Tickets.pClass, Persons.survived FROM Persons, Tickets WHERE Persons.peopleNo = Tickets.ticketsNo");
        int firstClassSurvivors = 0;
        int firstClassDeath = 0;
        int secondClassSurvivors = 0;
        int secondClassDeath = 0;
        int thirdClassSurvivors = 0;
        int thirdClassDeath = 0;

        while (resultPclass.next()) {
            String pClass = resultPclass.getString(1);
            String personsSatus = resultPclass.getString(2);
            switch (pClass) {
                case "1":
                    if(survivorsJudgement(personsSatus)) {
                        firstClassSurvivors ++;
                    } else {
                        firstClassDeath ++;
                    }
                    break;

                case "2":
                    if (survivorsJudgement(personsSatus)) {
                        secondClassSurvivors ++;
                    } else {
                        secondClassDeath ++;
                    }
                    break;

                case "3":
                    if (survivorsJudgement(personsSatus)) {
                        thirdClassSurvivors ++;
                    } else {
                        thirdClassDeath ++;
                    }
                    break;
                default:
                    System.out.println("there is one more class");
            }
        }
        //print out the output
        System.out.println(1 + ", " + 0 + ", " + firstClassDeath);
        System.out.println(1 + ", " + 1 + ", " + firstClassSurvivors);

        System.out.println(2 + ", " + 0 + ", " + secondClassDeath);
        System.out.println(2 + ", " + 1 + ", " + secondClassSurvivors);

        System.out.println(3 + ", " + 0 + ", " + thirdClassDeath);
        System.out.println(3 + ", " + 1 + ", " + thirdClassSurvivors);

        statement.close();
        connection.close();
    }

    /**
     *
     * @param status whether people is 1 or 0
     * @return true stands for survive, and false stands for death
     */
    public boolean survivorsJudgement(String status) {
        if (status.equals("1")) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * This method is for query4, which prints out the female death and survivors.
     * @throws SQLException SQL is no connection.
     */
    public void findMinAge() throws SQLException{
        Statement statement = connection.createStatement();
        ResultSet resultAge = statement.executeQuery("SELECT Persons.sex, Persons.age, Persons.survived FROM Persons");
        double femaleMinDeathAge = 1000;
        double femaleMinSurvivor = 1000;
        double maleMinDeathAge = 1000;
        double maleMinSurvivor = 1000;
        while (resultAge.next()) {
            String sex = resultAge.getString(1);
            String status = resultAge.getString(3);
            String ageString = resultAge.getString(2);
            double age = 0;
            //convert age to double
            if(ageString != null ) {
                age = Double.parseDouble(ageString);
            } else {
                age = 1000;
            }
            //sorting by sex.
            switch (sex) {
                //if the sex is female
                case "female":
                    if(survivorsJudgement(status)) {
                        if (findMinimum(femaleMinSurvivor, age)) { //if her age is smaller than current minimum age.
                            femaleMinSurvivor = age;
                        }

                    } else {// if the female is dead

                        if (findMinimum(femaleMinDeathAge, age)) {
                            femaleMinDeathAge = age;
                        }
                    }
                    break;
                //if the sex is male
                case "male":
                    if (survivorsJudgement(status)) {
                        if (findMinimum(maleMinSurvivor, age)) { //if his age is smaller than current minimum age.
                            maleMinSurvivor = age;
                        }
                    } else { // if the male is dead
                        if (findMinimum(maleMinDeathAge, age)) {
                            maleMinDeathAge = age;
                        }
                    }
                    break;
            }
        }

        System.out.println("female, " + 0 + ", " +femaleMinDeathAge);
        System.out.println("female, " + 1 + ", " + femaleMinSurvivor);
        System.out.println("male, " + 0 + ", " + maleMinDeathAge);
        System.out.println("male, " + 1 + ", " + maleMinSurvivor);
    }

    /**
     *
     * @param curMinAge The current minimum age.
     * @param curAge The new age that need to be compared.
     * @return true presents the current age is smaller than current age.
     */
    public boolean findMinimum(double curMinAge, double curAge) {
        if (curMinAge > curAge) {
            return true;
        } else {
            return false;
        }
    }


}
