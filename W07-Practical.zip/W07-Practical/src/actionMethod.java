import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;

/**
 * This class is for finding the method to execute, which is controlled by jdbcControl.java.
 */

public class actionMethod {
    private String fileLocation, dbUrl;
    private Connection connection = null;
    private static final int PASSENGER_ID = 0;
    private static final int SURVIVED = 1;
    private static final int PCLASS = 2;
    private static final int NAME = 3;
    private static final int SEX = 4;
    private static final int AGE = 5;
    private static final int SIBSP = 6;
    private static final int PARCH = 7;
    private static final int TICKET = 8;
    private static final int FARE = 9;
    private static final int CABIN = 10;
    private static final int EMBARKED = 11;

    private final int inValidNumber = 1000;
    private final int getStatusNumber = 3;
    private final int getNameNumber = 4;
    private final int lengthOfWordsList = 12;

    /**
     * This method is for storing the value that users enter.
     * @param dbFile The file name that is given by the users.
     * @param fileLocation The csv file that user wants to input.
     */

    public actionMethod(String dbFile, String fileLocation) {
        this.fileLocation = fileLocation;
        dbUrl = "jdbc:sqlite:" + dbFile;
    }

    /**
     * The method is to connect to the database.
     * @throws SQLException cannot connect the database.
     */

    public void accessDB() throws SQLException {
        try {
            connection = DriverManager.getConnection(dbUrl);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * This method will be used when the user enter 'create' option.
     * @throws SQLException when the SQL is not exist or cannot link to the database.
     * This method is associated with addDetail method.
     */

    public void createTable() throws SQLException {
        connection = DriverManager.getConnection(dbUrl);

        Statement statement = connection.createStatement();
        //create the table called persons.
        statement.executeUpdate("DROP TABLE IF EXISTS Persons");
        statement.executeUpdate(
                "CREATE TABLE Persons("
                        + "peopleNo INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + "passengerId INTEGER,"
                        + "survived INTEGER, "
                        + "name VARCHAR(50),"
                        + "sex VARCHAR(10),"
                        + "age FLOAT, "
                        + "sibSp INTEGER)"
        );

        //create the other table called boats.
        statement.executeUpdate("DROP TABLE IF EXISTS Tickets");
        statement.executeUpdate(
                "CREATE TABLE Tickets("
                        + "ticketsNo INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + "ticket VARCHAR(20),"
                        + "pClass INTEGER, "
                        + "parch INTEGER, "
                        + "fare FLOAT, "
                        + "embarked VARCHAR(2),"
                        + "cabin VARCHAR (6))");
        addDetails();
        statement.close();
        connection.close();
    }

    /**
     * This method is to add some details into the table, which is called by the method createTable().
     * @throws SQLException cannot link to the database.
     */
    public void addDetails() throws SQLException {
        Statement statement = connection.createStatement();
        // The following codes is to read the details in CSV file.
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(fileLocation));
            reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split(",");

                //insert the details into the table.
                for (int i = 0; i < words.length; i++) {
                    if (words[i].isEmpty()) {
                        words[i] = null;
                    }

                }

                // for empty large file
                ArrayList<String> wordsList = new ArrayList<>();
                for (int i = 0; i < words.length; i++) {
                    wordsList.add(words[i]);
                }
                if (wordsList.size() < lengthOfWordsList) {
                    wordsList.add(null);
                }

                //This is the control to insert info to Persons
                String updateString = "INSERT INTO Persons(passengerId, survived, name, sex, age, sibSp) VALUES("
                        + " " + wordsList.get(PASSENGER_ID) + ","
                        + " " + wordsList.get(SURVIVED) + ", "
                        + " \"" + wordsList.get(NAME).substring(1, wordsList.get(NAME).length() - 1).replaceAll("\"", "\"\"") + "\","
                        + " '" + wordsList.get(SEX) + "',"
                        + " " + wordsList.get(AGE) + ", "
                        + " " + wordsList.get(SIBSP) + ")";
                statement.executeUpdate(updateString);



                //This is the control to insert info to tickets
                updateString = "INSERT INTO Tickets(ticket, pClass, parch, fare, embarked, cabin) VALUES("
                        + " '" + wordsList.get(TICKET) + "', "
                        + " " + wordsList.get(PCLASS) + ", "
                        + " " + wordsList.get(PARCH) + ", "
                        + " " + wordsList.get(FARE) + ", "
                        + " '" + wordsList.get(EMBARKED) + "', "
                        + " '" + wordsList.get(CABIN) + "')";
                statement.executeUpdate(updateString);
            }
        } catch (IOException e) {
            e.getMessage();
        } finally {
                if (reader != null) {
                   try {
                       reader.close();
                   } catch (IOException error) {
                       error.getMessage();
                   }
                }
        }
        statement.close();
    }


    /**
     * this method is to print out the data in the database.
     * @throws SQLException when the SQL is not exist or cannot link to the database.
     */

    public void printTable() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSetPersons = statement.executeQuery("SELECT Persons.passengerId, Persons.survived, Tickets.pClass, Persons.name, Persons.sex, Persons.age,Persons.sibSp,"
                + "Tickets.parch, Tickets.ticket, Tickets.fare, Tickets.cabin, Tickets.embarked FROM Persons, Tickets WHERE Persons.peopleNo = Tickets.ticketsNo");
        ResultSetMetaData rsmd = resultSetPersons.getMetaData();
        int size = rsmd.getColumnCount();
        while (resultSetPersons.next()) {
            for (int i = 1; i <= size; i++) {
                if (i == size) { // the last details without information.
                    System.out.print(resultSetPersons.getString(i));
                }
                else if (i == getNameNumber) { //if this is a name
                    System.out.print("\"" + resultSetPersons.getString(i) + "\", ");
                }
                else { //if there is other element in the middle.
                    System.out.print(resultSetPersons.getString(i) + ", ");
                }
            }
            System.out.println();
        }
        statement.close();
        connection.close();
    }

    /**
     * This program is to count how many survivors in the boat, which is for query 2.
     * @throws SQLException when the SQL is not exist or cannot link to the database.
     */
    public void findSurvivors() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSurvivors = statement.executeQuery("SELECT Persons.survived FROM Persons");

        int countSurvivors = 0;
        while (resultSurvivors.next()) {
            String peopleSituation = resultSurvivors.getString(SURVIVED);
            //get the people who are survivors
            if (survivorsJudgement(peopleSituation)) {
                countSurvivors++;
            }
        }
        System.out.println(countSurvivors);
        statement.close();
        connection.close();
    }

    /**
     * This method is for query3, which call the method to judge whether people survive.
     * @throws SQLException when the SQL is not exist or cannot link to the database.
     */

    public void findPclass() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultPclass = statement.executeQuery("SELECT Tickets.pClass, Persons.survived FROM Persons, Tickets WHERE Persons.peopleNo = Tickets.ticketsNo");
        int firstClassSurvivors = 0;
        int firstClassDeath = 0;
        int secondClassSurvivors = 0;
        int secondClassDeath = 0;
        int thirdClassSurvivors = 0;
        int thirdClassDeath = 0;

        while (resultPclass.next()) {
            String pClass = resultPclass.getString(1);
            String personsSatus = resultPclass.getString(2);
            switch (pClass) {
                case "1":
                    if (survivorsJudgement(personsSatus)) {
                        firstClassSurvivors++;
                    } else {
                        firstClassDeath++;
                    }
                    break;

                case "2":
                    if (survivorsJudgement(personsSatus)) {
                        secondClassSurvivors++;
                    } else {
                        secondClassDeath++;
                    }
                    break;

                case "3":
                    if (survivorsJudgement(personsSatus)) {
                        thirdClassSurvivors++;
                    } else {
                        thirdClassDeath++;
                    }
                    break;
                default:
                    System.out.println("there is one more class");
            }
        }
        //print out the output
        System.out.println(1 + ", " + 0 + ", " + firstClassDeath);
        System.out.println(1 + ", " + 1 + ", " + firstClassSurvivors);

        System.out.println(2 + ", " + 0 + ", " + secondClassDeath);
        System.out.println(2 + ", " + 1 + ", " + secondClassSurvivors);

        System.out.println(getStatusNumber + ", " + 0 + ", " + thirdClassDeath);
        System.out.println(getStatusNumber + ", " + 1 + ", " + thirdClassSurvivors);

        statement.close();
        connection.close();
    }

    /**
     * This method makes a judgement whether user is a survivor or not.
     * @param status whether people is 1 or 0.
     * @return true stands for survive, and false stands for death.
     */
    public boolean survivorsJudgement(String status) {
        return status.equals("1");
    }

    /**
     * This method is for query4, which prints out the female death and survivors.
     * @throws SQLException SQL is no connection.
     */
    public void findMinAge() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultAge = statement.executeQuery("SELECT Persons.sex, Persons.age, Persons.survived FROM Persons");
        double femaleMinDeathAge = inValidNumber;
        double femaleMinSurvivor = inValidNumber;
        double maleMinDeathAge = inValidNumber;
        double maleMinSurvivor = inValidNumber;
        while (resultAge.next()) {
            String sex = resultAge.getString(1);
            String status = resultAge.getString(getStatusNumber);
            String ageString = resultAge.getString(2);
            double age = 0;
            //convert age to double
            if (ageString != null) {
                age = Double.parseDouble(ageString);
            } else {
                age = inValidNumber;
            }
            switch (sex) {
                //if the sex is female
                case "female":
                    if (survivorsJudgement(status)) {
                        if (findMinimum(femaleMinSurvivor, age)) { //if her age is smaller than current minimum age.
                            femaleMinSurvivor = age;
                        }

                    } else { // if the female is dead
                        if (findMinimum(femaleMinDeathAge, age)) {
                            femaleMinDeathAge = age;
                        }
                    }
                    break;
                //if the sex is male
                case "male":
                    if (survivorsJudgement(status)) {
                        if (findMinimum(maleMinSurvivor, age)) { //if his age is smaller than current minimum age.
                            maleMinSurvivor = age;
                        }
                    } else { // if the male is dead
                        if (findMinimum(maleMinDeathAge, age)) {
                            maleMinDeathAge = age;
                        }
                    }
                    break;
                default:
                    System.out.println("This is invalid");
            }
        }

        System.out.println("female, " + 0 + ", " + femaleMinDeathAge);
        System.out.println("female, " + 1 + ", " + femaleMinSurvivor);
        System.out.println("male, " + 0 + ", " + maleMinDeathAge);
        System.out.println("male, " + 1 + ", " + maleMinSurvivor);
    }

    /**
     * The method is to find the minimum age.
     * @param curMinAge The current minimum age.
     * @param curAge The new age that need to be compared.
     * @return true presents the current age is smaller than current age.
     */
    public boolean findMinimum(double curMinAge, double curAge) {
        return curMinAge > curAge;
    }


}
