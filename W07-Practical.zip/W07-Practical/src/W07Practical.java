import java.sql.SQLException;

/**
 * This is for executing W07Practical.
 */
public class W07Practical {
    private static final int GET_ARGUMENTS_NUMBER = 3;
    /**
     * This method is for execution for the whole practical.
     * @param args users enter.
     * @throws SQLException cannot find the SQL
     */
    public static void main(String[] args) throws SQLException {
        // If the program args are less or more
        if (args.length < 2 || args.length > GET_ARGUMENTS_NUMBER) {
            System.out.println("Usage: java -cp sqlite-jdbc.jar:. W07Practical <db_file> <action> [input_file]");
        } else {
            // This is for creating a file
            if (args.length == GET_ARGUMENTS_NUMBER) {
                jdbcControl control = new jdbcControl(args[0], args[1], args[2]);
            } else {
                jdbcControl control = new jdbcControl(args[0], args[1]);
            }
        }
    }
}
