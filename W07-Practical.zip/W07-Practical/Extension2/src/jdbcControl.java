import java.sql.SQLException;

/**
 * This class is for finding the query that user wants, which is executed by W07Practical.java.
 */
public class jdbcControl {
    private String action;
    private actionMethod finder;

    /**
     * This method is to pass the user entering from users for query1.
     * @param dbFile the file name is to be read.
     * @param action the query String that user enter.
     * @param fileLocation the file need to be read.
     * @throws SQLException cannot connect to database
     */
    public jdbcControl(String dbFile, String action, String fileLocation) throws SQLException {
        this.action = action;
        finder = new actionMethod(dbFile, fileLocation);
        actionSelect();
    }

    /**
     * This method is to pass the user entering from users for query2, query3, query4.
     * @param dbFile which is the file that users give.
     * @param action the query that user enters
     * @throws SQLException cannot connect to SQL
     */
    public jdbcControl(String dbFile, String action) throws SQLException {
        this.action = action;
        finder = new actionMethod(dbFile, "not necessary");
        actionSelect();
    }

    /**
     * According to user's query enter, the method will conduct the action.
     * @throws SQLException cannot connect to sql.
     */
    public void actionSelect() throws SQLException {
        switch (action) {
            case "create":
                System.out.println("OK");
                finder.createTable();
                break;
            case "query1":
                System.out.println("passengerId, survived, pClass, name, sex, age, sibSp, parch, ticket, fare, cabin, embarked");
                finder.accessDB();
                finder.printTable();
                break;

            case "query2":
                System.out.println("Number of Survivors");
                finder.accessDB();
                finder.findSurvivorsSQL();
                break;

            case "query3":
                System.out.println("pClass, survived, count");
                finder.accessDB();
                finder.pClassWithSurvivorsSQL();
                break;

            case "query4":
                System.out.println("sex, survived, minimum age");
                finder.accessDB();
                finder.sexMinimumAgeSQL();
                break;
            default:
                System.out.println("Please enter correct query number");

        }
    }
}
