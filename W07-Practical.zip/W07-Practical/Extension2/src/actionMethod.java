import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;

/**
 * This class is for finding the method to execute, which is controlled by jdbcControl.java.
 */

public class actionMethod {
    private String fileLocation, dbUrl;
    private Connection connection = null;
    private static final int PASSENGER_ID = 0;
    private static final int SURVIVED = 1;
    private static final int PCLASS = 2;
    private static final int NAME = 3;
    private static final int SEX = 4;
    private static final int AGE = 5;
    private static final int SIBSP = 6;
    private static final int PARCH = 7;
    private static final int TICKET = 8;
    private static final int FARE = 9;
    private static final int CABIN = 10;
    private static final int EMBARKED = 11;

    private final int inValidNumber = 1000;
    private final int getStatusNumber = 3;
    private final int getNameNumber = 4;
    private final int lengthOfWordsList = 12;

    /**
     * This method is for storing the value that users enter.
     * @param dbFile The file name that is given by the users.
     * @param fileLocation The csv file that user wants to input.
     */

    public actionMethod(String dbFile, String fileLocation) {
        this.fileLocation = fileLocation;
        dbUrl = "jdbc:sqlite:" + dbFile;
    }

    /**
     * The method is to connect to the database.
     * @throws SQLException cannot connect the database.
     */

    public void accessDB() throws SQLException {
        try {
            connection = DriverManager.getConnection(dbUrl);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * This method will be used when the user enter 'create' option.
     * @throws SQLException when the SQL is not exist or cannot link to the database.
     * This method is associated with addDetail method.
     */

    public void createTable() throws SQLException {
        connection = DriverManager.getConnection(dbUrl);

        Statement statement = connection.createStatement();
        //create the table called persons.
        statement.executeUpdate("DROP TABLE IF EXISTS Persons");
        statement.executeUpdate(
                "CREATE TABLE Persons("
                        + "peopleNo INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + "passengerId INTEGER,"
                        + "survived INTEGER, "
                        + "name VARCHAR(50),"
                        + "sex VARCHAR(10),"
                        + "age FLOAT, "
                        + "sibSp INTEGER)"
        );

        //create the other table called boats.
        statement.executeUpdate("DROP TABLE IF EXISTS Tickets");
        statement.executeUpdate(
                "CREATE TABLE Tickets("
                        + "ticketsNo INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + "ticket VARCHAR(20),"
                        + "pClass INTEGER, "
                        + "parch INTEGER, "
                        + "fare FLOAT, "
                        + "embarked VARCHAR(2),"
                        + "cabin VARCHAR (6))");
        addDetails();
        statement.close();
        connection.close();
    }

    /**
     * This method is to add some details into the table, which is called by the method createTable().
     * @throws SQLException cannot link to the database.
     */
    public void addDetails() throws SQLException {
        Statement statement = connection.createStatement();
        // The following codes is to read the details in CSV file.
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(fileLocation));
            reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split(",");

                //insert the details into the table.
                for (int i = 0; i < words.length; i++) {
                    if (words[i].isEmpty()) {
                        words[i] = null;
                    }

                }

                // for empty large file
                ArrayList<String> wordsList = new ArrayList<>();
                for (int i = 0; i < words.length; i++) {
                    wordsList.add(words[i]);
                }
                if (wordsList.size() < lengthOfWordsList) {
                    wordsList.add(null);
                }

                //This is the control to insert info to Persons
                String updateString = "INSERT INTO Persons(passengerId, survived, name, sex, age, sibSp) VALUES("
                        + " " + wordsList.get(PASSENGER_ID) + ","
                        + " " + wordsList.get(SURVIVED) + ", "
                        + " " + wordsList.get(NAME) + ","
                        + " '" + wordsList.get(SEX) + "',"
                        + " " + wordsList.get(AGE) + ", "
                        + " " + wordsList.get(SIBSP) + ")";
                statement.executeUpdate(updateString);

                //This is the control to insert info to tickets
                updateString = "INSERT INTO Tickets(ticket, pClass, parch, fare, embarked, cabin) VALUES("
                        + " '" + wordsList.get(TICKET) + "', "
                        + " " + wordsList.get(PCLASS) + ", "
                        + " " + wordsList.get(PARCH) + ", "
                        + " " + wordsList.get(FARE) + ", "
                        + " '" + wordsList.get(EMBARKED) + "', "
                        + " '" + wordsList.get(CABIN) + "')";
                statement.executeUpdate(updateString);
            }
        } catch (IOException e) {
            e.getMessage();
        } finally {
                if (reader != null) {
                   try {
                       reader.close();
                   } catch (IOException error) {
                       error.getMessage();
                   }
                }
        }
        statement.close();
    }


    /**
     * this method is to print out the data in the database.
     * @throws SQLException when the SQL is not exist or cannot link to the database.
     */

    public void printTable() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSetPersons = statement.executeQuery(
                "SELECT Persons.passengerId, Persons.survived, Tickets.pClass, Persons.name, Persons.sex, Persons.age,Persons.sibSp,"
                + "Tickets.parch, Tickets.ticket, Tickets.fare, Tickets.cabin, Tickets.embarked " +
                        "FROM Persons, Tickets " +
                        "WHERE Persons.peopleNo = Tickets.ticketsNo");
        ResultSetMetaData rsmd = resultSetPersons.getMetaData();
        int size = rsmd.getColumnCount();
        while (resultSetPersons.next()) {
            for (int i = 1; i <= size; i++) {
                if (i == size) { // the last details without information.
                    System.out.print(resultSetPersons.getString(i));
                }
                else if (i == getNameNumber) { //if this is a name
                    System.out.print("\"" + resultSetPersons.getString(i) + "\", ");
                }
                else {
                    System.out.print(resultSetPersons.getString(i) + ", ");
                }
            }
            System.out.println();
        }
        statement.close();
        connection.close();
    }


    /**
     * This method is to count the survivors by using SQL syntax.
     * @throws SQLException cannot connect to the database.
     */
    public void findSurvivorsSQL() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet surivivorsSql = statement.executeQuery(
                "SELECT Persons.survived, COUNT (Persons.survived) " +
                        "FROM Persons " +
                        "WHERE Persons.survived = '1' " +
                        "GROUP BY Persons.survived ");
        //print out the number of survivors.
        System.out.println(surivivorsSql.getString(2));

        statement.close();
        connection.close();
    }

    /**
     * This method is to find the pClass as well as the survivors with counting numbers.
     * @throws SQLException
     */
    public void pClassWithSurvivorsSQL() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet pClassSql = statement.executeQuery("SELECT pClass, Persons.survived, COUNT (Persons.survived) " +
                "FROM Persons INNER JOIN Tickets ON Tickets.ticketsNo = Persons.peopleNo  GROUP BY pClass, Persons.survived" +
                "");
        while (pClassSql.next()) {
            System.out.print(pClassSql.getString(1) + ", ");
            System.out.print(pClassSql.getString(2) + ", ");
            System.out.print(pClassSql.getString(3));
            System.out.println();
        }
        statement.close();
        connection.close();
    }

    /**
     * This method is to find out the minimum age by sorting with sex.
     * @throws SQLException cannot connect to database.
     */
    public void sexMinimumAgeSQL() throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet sexMinAge = statement.executeQuery(
                "SELECT sex, survived, min (Persons.age) FROM Persons GROUP BY sex, survived");
        while (sexMinAge.next()) {
            System.out.print(sexMinAge.getString(1) + ", ");
            System.out.print(sexMinAge.getString(2) + ", ");
            System.out.print(sexMinAge.getString(3));
            System.out.println();
        }
        statement.close();
        connection.close();
    }


}
